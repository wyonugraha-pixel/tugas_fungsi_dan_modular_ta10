def hitung_rata(data):
    total = 0
    for nilai in data:
        total += nilai
    return total / len(data)


def status_lulus(rata):
    if rata >= 75:
        return "Lulus"
    else:
        return "Tidak Lulus"


def nilai_tertinggi(data):
    tertinggi = data[0]
    for nilai in data:
        if nilai > tertinggi:
            tertinggi = nilai
    return tertinggi
