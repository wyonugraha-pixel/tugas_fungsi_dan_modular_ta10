import utils

nilai_mahasiswa = []
jumlah = int(input("Masukkan jumlah nilai mahasiswa: "))

for i in range(jumlah):
    nilai = int(input(f"Masukkan nilai ke-{i+1}: "))
    nilai_mahasiswa.append(nilai)

print("\nData nilai:", nilai_mahasiswa)

rata = utils.hitung_rata(nilai_mahasiswa)
print("Rata-rata nilai:", rata)

status = utils.status_lulus(rata)
print("Status:", status)

tertinggi = utils.nilai_tertinggi(nilai_mahasiswa)
print("Nilai tertinggi:", tertinggi)
